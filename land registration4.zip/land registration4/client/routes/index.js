'use strict'
var express = require('express');
var router = express.Router();
var {Property} = require('./Userclient')

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('dashboards', { title: 'Dashboards' });
});
router.get('/listProperties',async(req,res)=>{
  var propertyClient =new Property();
  let stateData =await propertyClient.getPropertyListings();
  //console.log("listings",stateData);//
  let listProperties =[];
  stateData.data.forEach(properties=>{
    if(!properties.data) return;
    let decodedProperties =Buffer.from(properties.data,'base64').ioString();
    let propertyDetails = decodedProperties.split(',');

    listProperties.push({
      OwnNam: propertyDetails[6],
      Aadno : propertyDetails[4],
      LArea: propertyDetails[3],
      adrs:propertyDetails[9],
      status:(propertyDetails.length === 5)?"Not Registered":"Registered",
      doa: propertyDetails[2],
      adrs:propertyDetails[9],
      dor:propertyDetails[2],
      sur:propertyDetails[3],
      dist:propertyDetails[4]
      
    });
  
});
res.render('listProperties',{listings: listProperties});
});

router.get('/homePage',(req,res)=>{
    res.render('dashboards',{title:'Dashboards'});

});

router.post('/addProperty',function(req,res){
  let key= req.body.key
  let own=req.body.owner
  let aad=req.body.owneraad
  let lan=req.body.land
  let da =req.body.date  
  let add=req.body.addresss
  let mob=req.body.mobile
  let nom=req.body.nominee
  let nad=req.body.nomineeAad
  console.log("Data sent to REST API");
  var client = new Property();
  client.addProperty("Application",key,own,lan,aad,da,add,mob,nom,nad)
  res.send({message:"Data successfully added"});
  
  

})
router.post('/registerProperty',function(req,res){
  let key= req.body.key
  let Ownname=req.body.owner
  let ownaad=req.body.Aad
  let da=req.body.date
  let adrs=req.body.addresss
  let district=req.body.district
  let survey=req.body.survey

  console.log("Datasent to REST API");
  var client= new Property();
  client.registerProperty("Registrar",key,Ownname,ownaad,larea,da,adrs,district,survey)
  res.send({message:"Data succesfully added"});


})
module.exports = router;
