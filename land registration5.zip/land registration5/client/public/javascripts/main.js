<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
function viewData() {
    window.location.href='/listView';

}

function getPropertyAddress(OwnerName,Aadnum,MobNumb){
    let keyHash =hash(getUserPublicKey(OwnerName))
    let nameHash =hash("Property Chain")
    let Aadhash =hash(Aadnum)
    let Mobhash =hash(MobNumb)
    return nameHash.slice(0,6) +Aadhash.slice(0,6)+Mobhash.slice(0,6)+keyHash.slice(0,52)
}
function addPropertyAsOwner(event) {
    event.preventDefault();
    let privKey =document.getElementById('ownPrivKey').value;
    let OwnNam =document.getElementById('ownName').value;
    let Aadnum =document.getElementById('Ownaad').value;
    let LArea =document.getElementById('larea').value;
    let doa =document.getElementById('doa').value;
    let Addrs =document.getElementById('addr').value;
    let MobNumb =document.getElementById('mob').value;
    $.post('/addProperty',{key:privKey,owneraad:Aadnum,owner:OwnNam,land:LArea,date:doa,address:Addrs,mobile:MobNumb,nominee:NomNam,nomineeAad:NomAad},'json')

 
}

function addPropertyAsRegister(event) {
    event.preventDefault();
    let privKey =document.getElementById('regPrivKey').value;
    let OwnNam =document.getElementById('ownname').value;
    let Aadno  =document.getElementById('ownAad').value;
    let adrs =document.getElementById('addrs').value;
    let dor =document.getElementById('DOR').value;
    let dist =document.getElementById('District').value;
    let sur =document.getElementById('survey').value;
    $.post('/registerProperty',{key:privKey,owner:OwnNam,Aad:Aadno,Address:adrs,date:dor,district:dist,survey:sur},'json')
        
}
function listproperties(event){
    event.preventDefault();
    console.log("listproperties(event)");
    window.location.href='/listProperties';
}