'use strict'
const {TransactionProcessor} =require('sawtooth-sdk/processor');
const Property =require('./Handler');
const URL ='tcp://validation:4004';

const transactionProcessor =new TransactionProcessor(URL);
transactionProcessor.addHandler(new Property());
transactionProcessor.start();