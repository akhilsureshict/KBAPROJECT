'use strict'
const fetch = require('node-fetch');
const crypto = require('crypto');
const {CryptoFactory, createContext} =require('sawtooth-sdk/signing')
const protobuf =require('sawtooth-sdk/protobuf')
const {Secp256k1PrivateKey} =require('sawtooth-sdk/signing/secp256k1')
const {TextEncoder} =require('text-encoding/lib/encoding')
var encoder =new TextEncoder('utf8');

const APPLICATIONKEY = '8f99bb8b1dc799fd1ed9b7e370330f9378c78f7c332ac3e2233bf559ce21ea8b'
const REGISTERATIONKEY = '4206848f09f0953370fc3e4a131faeab07e239d451190294e5049cfcf05a107e'

const FAMILY_NAME = 'Property Chain'

function hash(data) {
    return crypto.createHash('sha512').update(data).digest('hex');

}
function getPropertyAddress(Aadnum,MobNum){
    const context = createContext('secp256k1');
    let key = Secp256k1PrivateKey.fromHex(APPLICATIONKEY)
    let signer = new CryptoFactory(context).newSigner(key);
    let publicKeyHex =signer.getPublicKey().asHex()
    let KeyHash = hash(publicKeyHex)
    let nameHash = hash("Property Chain")
    let AadHash =hash(Aadnum)
    let MobHash =hash(MobNum)
    return nameHash.slice(0,6) +AadHash.slice(0,6)+MobHash.slice(0,6)+KeyHash.slice(0,52)
}

/* function to create transaction
familyName - the transaction family name
inputlist -list of input address
outputlist -list of output address
privkey- the userpublickey
payload -payload
familyVersion -the version of the family*/

function createTransaction(familyName,inputList,outputList,Privkey,payload,familyVersion ='1.0'){
    const privateKeyHex = Privkey
    const context =createContext('secp256k1');
    const secp256k1pk =Secp256k1PrivateKey.fromHex(privateKeyHex.trim());
    signer =new CryptoFactory(context).newSigner(secp256k1pk);
    const payloadBytes =encode.encode(payload)
    //create transaction header
    const transactionHeaderBytes =protobuf.TransactionHeader.encode({
        familyName:familyName,
        familyVersion:familyVersion,
        inputs: inputList,
        outputs:outputList,
        signerPublicKey:signer.getPublicKey().asHex(),
        nonce: "" + Math.random(),
        batcherPublicKey: signer.getPublicKey().asHex(),
        dependencies:[],
        payloadSha512: hash(payloadBytes),
    }).finish();
    //create transaction
    const transaction = protobuf.Transaction.create({
        header:transactionHeaderBytes,
        headerSignature:signer.sign(transactionHeaderBytes),
        payload: payloadBytes

    });
    const transactions =[transaction];
    //create batch header
    const batchHeaderBytes =protobuf.BatchHeader.encode({
    signerPublicKey:signer.getPublicKey().asHex(),
    transactionIds:transactions.map((txn) => txn.headerSignature),    
    }).finish();
    //createbatch
    const batch = protobuf.Batch.create({
        header:batchHeaderBytes,
        headerSignature: batchSignature,
        transactions: transactions,
    });
    //create batchlist
    const batchListBytes = protobuf.BatchList.encode({
        batches: [batch]
    }).finish();
    sendTransaction(batchListBytes);
}
/*function to submit the batchListBytes to validator*/
async function sendTransaction(batchListBytes){
  
    let resp =await fetch('http://rest-api:8008/batches', {
       method: 'POST',
       headers: { 'Content-Type': 'application/octet-stream'},
       body: batchListBytes
       })
          console.log("response", resp);
 }
//class for propertty
class Property{

/*function to add new property
    owner-name of owner
    Key-key that is avaliable for user
    Aadnum-aadhar number of owner
    LArea- land area to be registered
    doa-date of application
    Addrs-Address of owner
    MobNum-mobile number of owner
    NomNam-nominee name
    Nomaad-nominee aadhar number*/
   async addProperty(OwnNam,Key,Aadnum,LArea,doa,Addrs,MobNum,NomNam,Nomaad){
    try{    
    let address = getPropertyAddress(Aadnum)
        let action ="Add Property"
        let payload=[action,OwnNam,LArea,doa,Addrs,MobNum,NomNam,Nomaad].join(',')
        if (Key == APPLICATIONKEY){
            createTransaction(FAMILY_NAME,[address],[address],Key,payload)}
            else{
                console.log('Land owner is not eligible to register')
            }}
            catch(error){
            console.error(error);
            }
        }

    

/* function to add register details of the property added
    Ownnam -name of owner
    registerey -key for registration
    Aadno -aadhar no of owner
    adrs -owner address
    dor -date of registeration
    dist-distict where property is located
    sur-survey number*/
   async registerProperty(OwnNam,registerkey,Aadno,adrs,dor,dist,sur){
       try{
      let action ="Register Property"
      let Address= getPropertyAddress(Aadno)
      let payload =[action,OwnNam,Aadno,adrs,dor,dist,sur].join(',')
      if(registerkey == REGISTERATIONKEY){
          createTransaction(FAMILY_NAME,[Address],[Address],register,payload)
      }
      else{
          console.log('Registrar not authorized')
      }}
      catch(error){
          console.error(error);
      }
    }     
                    

          

        
/*
*get state from the REST API
*@param (*) address The state address to get
*@param (*) isQuery Is this an address space query or full address
*/
async getState (address, isQuery) {
  let stateRequest = 'http://rest-api:8008/state';
  if(address) {
    if(isQuery) {
      stateRequest += ('?address=')
    } else {
      stateRequest += ('/address/');
    }
    stateRequest += address;
  }
  let stateResponse = await fetch(stateRequest);
  let stateJSON = await stateResponse.json();
  return stateJSON;
}

async  getPropertyListings() {
  
  let PropertyListingAddress = hash(FAMILY_NAME).substr(0, 6);
  return this.getState(PropertyListingAddress,true);
   
}

//////

}




module.exports = {Property};