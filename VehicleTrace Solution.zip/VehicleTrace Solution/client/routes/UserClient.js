const fetch = require('node-fetch');
const crypto = require('crypto');
const {CryptoFactory, createContext } = require('sawtooth-sdk/signing')
const protobuf = require('sawtooth-sdk/protobuf')
const {Secp256k1PrivateKey} = require('sawtooth-sdk/signing/secp256k1') 
const {TextEncoder} = require('text-encoding/lib/encoding')
var encoder =new TextEncoder('utf8');



//Approved keys for manufacturer and registrar
MANUFACTURERKEY = '8f99bb8b1dc799fd1ed9b7e370330f9378c78f7c332ac3e2233bf559ce21ea8b'
REGISTERKEY = '4206848f09f0953370fc3e4a131faeab07e239d451190294e5049cfcf05a107e'

//family name
FAMILY_NAME='Vehicle Chain'


// function to hash data
function hash(data) {
  return crypto.createHash('sha512').update(data).digest('hex');
}

/* function to retrive the address of a particular vehicle based on its vin number */

function getVehicleAddress(vinNumber){
  const context = createContext('secp256k1');
  let key = Secp256k1PrivateKey.fromHex(MANUFACTURERKEY)
  let signer = new CryptoFactory(context).newSigner(key);
  let publicKeyHex = signer.getPublicKey().asHex()    
  let keyHash  = hash(publicKeyHex)
  let nameHash = hash("Vehicle Chain")
  let vinHash = hash(vinNumber)
  return nameHash.slice(0,6) +vinHash.slice(0,6)+keyHash.slice(0,58)

}
/* function to create Transaction 
parameter : 
familyName -  the transaction family name 
inputlist - list of input addressess
outputlist - list of output addressess
privkey - the user private key
payload - payload
familyVersion - the version of the family
*/
function createTransaction(familyName,inputList,outputList,Privkey,payload,familyVersion = '1.0'){
  const privateKeyHex = Privkey  
  const context = createContext('secp256k1');
  const secp256k1pk = Secp256k1PrivateKey.fromHex(privateKeyHex.trim());
  signer = new CryptoFactory(context).newSigner(secp256k1pk);
  const payloadBytes = encoder.encode(payload)
  //create transaction header
  const transactionHeaderBytes = protobuf.TransactionHeader.encode({
    familyName: familyName,
    familyVersion: familyVersion,
    inputs: inputList,
    outputs: outputList,
    signerPublicKey: signer.getPublicKey().asHex(),
    nonce: "" + Math.random(),
    batcherPublicKey: signer.getPublicKey().asHex(),
    dependencies: [],
    payloadSha512: hash(payloadBytes),
  }).finish();
  // create transaction
  const transaction = protobuf.Transaction.create({
    header: transactionHeaderBytes,
    headerSignature: signer.sign(transactionHeaderBytes),
    payload: payloadBytes
  });
  const transactions = [transaction];
  //create batch header
  const  batchHeaderBytes = protobuf.BatchHeader.encode({
    signerPublicKey: signer.getPublicKey().asHex(),
    transactionIds: transactions.map((txn) => txn.headerSignature),
  }).finish();

  const batchSignature = signer.sign(batchHeaderBytes);
  //create batch 
  const batch = protobuf.Batch.create({
    header: batchHeaderBytes,
    headerSignature: batchSignature,
    transactions: transactions,
  });
  //create batchlist
  const batchListBytes = protobuf.BatchList.encode({
    batches: [batch]
  }).finish();

  sendTransaction(batchListBytes);	
}

/*
function to submit the batchListBytes to validator
*/
async function sendTransaction(batchListBytes){
  
   let resp =await fetch('http://rest-api:8008/batches', {
      method: 'POST',
      headers: { 'Content-Type': 'application/octet-stream'},
      body: batchListBytes
      })
         console.log("response", resp);
}

// class for vehicle
class Vehicle{

      /* function to add newly manufactured vehicle to chain
      parameters :
      manufacturer - name of the manufacturer
      Key - key that is available to the manufacturer
      vinNumber - vehicle vinNumber
      dom - date of manufacturing
      model - model of  the car 
      engineNumber - serial no of engine
      */
      addVehicle(manufacturer,Key,vinNumber,dom,model,engineNumber){

        let address = getVehicleAddress(vinNumber)
        let action = "Add Vehicle"
        let payload = [action,manufacturer,vinNumber,dom,model,engineNumber].join(',')
        if (Key == MANUFACTURERKEY){
        	createTransaction(FAMILY_NAME,[address],[address],Key,payload)}
        else{
        	console.log('manufacturer Not Authorised')
        }

      }
      /* function to add register details manufactured vehicle to chain
      parameters :
      Registrar - Registering authority
      registrarKey - key of registrar
      vinNumber - vehicle vinNumber
      dor - date of registration
      owner - owner of  the car 
      platenumber - platenumber of car 
      address - owners address
      */

      registerVehicle(Registrar,registrarKey,vinNumber,dor,owner,plateNumber,address){
        let action = "Register Vehicle"
        let Address = getVehicleAddress(vinNumber)
        let payload = [action,vinNumber,dor,owner,plateNumber,Registrar,address].join(',')
        if (registrarKey == REGISTERKEY){
        	createTransaction(FAMILY_NAME,[Address],[Address],registrarKey,payload)
        }
        else{
        	console.log('Registrar Not Authorised')
        }
        

    }


//////

/**
 * Get state from the REST API
 * @param {*} address The state address to get
 * @param {*} isQuery Is this an address space query or full address
 */
async getState (address, isQuery) {
  let stateRequest = 'http://rest-api:8008/state';
  if(address) {
    if(isQuery) {
      stateRequest += ('?address=')
    } else {
      stateRequest += ('/address/');
    }
    stateRequest += address;
  }
  let stateResponse = await fetch(stateRequest);
  let stateJSON = await stateResponse.json();
  return stateJSON;
}

async getVehicleListings() {
  let vehicleListingAddress = hash(FAMILY_NAME).substr(0, 6);
  return this.getState(vehicleListingAddress, true);
}

//////

}

module.exports = {Vehicle};
